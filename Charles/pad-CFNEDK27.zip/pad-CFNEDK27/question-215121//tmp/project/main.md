 ## System Design
 We want to build a system to answer this question: of COVID diagnostic tests with a positive result, what percentage were for people that were unvaccinated, partially vaccinated, and fully vaccinated?


 # Constraints
 - timeframe ~ 2021

 Data:
  - sources?
    - partner network including government and private, e.g. pharmacy
    - adding sources later can retroactively affect existing data
    - two sources, overlapping but not the same partners
    - multiple sources about the same person? yes, but not likely about the same event

# output format?
  - users are researchers investigating public health and vaccines
  - aggregations?
    - Are they looking at individuals? Regions or demographics?
    - Delivered on a cadence?
    - near real-time? No, but 24-hour SLA on using data

# how do we get the data?
  - lots of smaller locations to submit data
  - Basic portal to login, add the data of both types
  - probably not restricted to the past X days? Correct
  - How do we handle PII? Prior to submission?
    - use the DV token? Yes, assume it's perfect and handled before submission
  - Give them a lightweight sight to upload the data?
  - Partner auth? Yes, don't drill in here for this exercise

# DB
  - Relational, PG
  - Probably a couple tables

  
 - Test_results
  - token
  - partner_id
  - date/timestamp
  - +/- (outcome)
  - entereddatetime
 - vaccination_records
  - token
  - partner_id
  - date
  - brand/type
  - entereddatetime
 - partner - some regional info?
  - login info
  - region
 - partner_submission
  - date
  - number of tests
  - number of vaccines
- token_status
  - token
- positive results
  - 
- Separate table for aggregate results?
  - batch calculate in off-hours?
  - maybe depends on how they use the data, e.g. YTD etc. isn't clear yet
  - latest data no matter what, or rolling 24-hour window

  - Test_result records with NO vaccination entries
  - test_result records with vaccination entries
    - date alignment - check for window
    - vaccine type
      - calculating fully or partially vaccinated


# Ingestion details
 - give them a grid to paste rows into
 - also a CSV upload
 - validate live, show them what went wrong
 - don't kill the batch because of a bad character